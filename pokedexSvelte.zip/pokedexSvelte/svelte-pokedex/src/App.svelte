<script>
  import Pokedex from "./lib/Pokedex.svelte";
</script>

<main>
  <Pokedex />
</main>

<style lang="postcss">
</style>
