<script>
    import "../app.css";
  </script>
  
  <nav>
    <a href="/">Home</a>
    <a href="/about">About</a>
  </nav>
  <slot />